import React from 'react'

export default function Header(){
  return (
    <header className="text-center py-10 bg-[rgba(216,201,179,0.4)] border-b border-kt-beige">
      <h1 className="text-4xl font-serif font-bold tracking-tight" style={{color:'#a98f6d'}}>Presenting KnackTime Books</h1>
      <p className="mt-2 text-lg italic text-kt-muted">“Buckle your read-belt and enjoy.”</p>
      <p className="mt-2 text-sm text-gray-700 uppercase tracking-wide">Sports Fiction • Political Fiction • Mystery/Suspense • Romance • Literary Fiction</p>
      <div className="mt-4 flex items-center justify-center gap-3">
        <img src="/assets/popcorn.svg" alt="popcorn" title="Snack time!" className="w-10 h-10" />
        <img src="/assets/pizza.svg" alt="pizza" title="Story time treat!" className="w-12 h-12" />
      </div>
    </header>
  )
}
