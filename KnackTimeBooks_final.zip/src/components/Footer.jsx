import React from 'react'

export default function Footer(){
  return (
    <footer className="mt-8 py-8 text-center text-sm text-gray-700 border-t border-kt-beige bg-[rgba(169,143,109,0.06)]">
      <div className="max-w-3xl mx-auto">
        <p className="mb-3 text-[14px] text-gray-700 italic">Candace Taylor Johnson is the author of the Nella series and Lastview. Her work explores small-town life, the rhythm of work, and the quiet choices that shape people's lives.</p>
        <p className="mb-2">Want updates? Email <a href="mailto:you@example.com" className="underline">you@example.com</a> or follow on <a href="#" className="underline">X</a> / <a href="#" className="underline">Instagram</a>.</p>
        <p className="text-xs text-gray-500">© 2025 Candace Taylor Johnson — All Rights Reserved</p>

        <div className="mt-3 flex items-center justify-center gap-3">
          <img src="/assets/popcorn-mini.svg" alt="popcorn" className="w-6 h-6" />
          <img src="/assets/pizza-mini.svg" alt="pizza" className="w-6 h-6" />
        </div>
      </div>
    </footer>
  )
}
