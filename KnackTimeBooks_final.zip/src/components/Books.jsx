import React from 'react'
import { motion } from 'framer-motion'

const books = [
  { id:1, title: 'Nella: A Ballpark Worker', blurb: 'Follow Nella in and out of the ballpark.', link: 'https://www.amazon.com/Ballpark-Worker-Candace-Taylor-Johnson-ebook/dp/B009PX58W8/' },
  { id:2, title: 'Nella: A Novella — Day Book II', blurb: 'A new day begins for Nella.', link: 'https://www.amazon.com/Nella-Novella-Book-Ballpark-Worker/dp/1724947133' },
  { id:3, title: 'Lastview', blurb: 'A district attorney running for governor in Lastview.', link: 'https://www.amazon.com/LASTVIEW-Candace-Taylor-Johnson-ebook/dp/B010OQRHZK' }
]

export default function Books(){
  return (
    <section>
      <h2 className="text-2xl font-bold text-center mb-6" style={{color:'#a98f6d'}}>Featured Novels</h2>
      <div className="flex gap-6 overflow-x-auto snap-x snap-mandatory pb-6">
        {books.map((b, i) => (
          <motion.article key={b.id} className="snap-center min-w-[300px] bg-white/60 backdrop-blur-md rounded-2xl p-6 shadow-md" initial={{opacity:0, y:20}} whileInView={{opacity:1, y:0}} viewport={{once:true}} transition={{delay: i*0.25, duration: 0.9}}>
            <div className="w-48 h-64 mx-auto mb-4 cover rounded-md overflow-hidden">
              <img src={`/assets/cover${b.id}.jpg`} alt={b.title} className="w-full h-full object-cover" />
            </div>
            <h3 className="text-lg font-semibold text-center" style={{color:'#a98f6d'}}>{b.title}</h3>
            <p className="text-sm italic text-center text-gray-700 mt-2">{b.blurb}</p>
            <div className="mt-4 flex justify-center">
              <a className="inline-flex items-center gap-2 px-4 py-2 rounded-full border button-amazon" href={b.link} target="_blank" rel="noreferrer" style={{borderColor:'#d8c9b3'}}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M2 12s4 6 10 6 10-6 10-6" stroke="#FF9900" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
                <span className="text-sm">Now on Amazon</span>
              </a>
            </div>
          </motion.article>
        ))}
      </div>
    </section>
  )
}
