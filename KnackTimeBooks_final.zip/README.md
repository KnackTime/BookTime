# CandaceTaylorJohnsonBooks (KnackTime Books)

This is a ready-to-deploy React + Vite site to showcase Candace Taylor Johnson's novels.

## Quick start
1. Run `npm install`
2. Run `npm run dev` to preview locally
3. Run `npm run build` to produce `dist` for deployment

## Deploy to Netlify
1. Push this repo to GitHub
2. In Netlify, import from GitHub
3. Set build command: `npm run build` and publish directory: `dist`
