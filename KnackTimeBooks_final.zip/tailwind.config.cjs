module.exports = {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        'kt-beige': '#d8c9b3',
        'kt-dark': '#a98f6d',
        'kt-muted': '#7a6b5a'
      }
    }
  },
  plugins: [],
}
